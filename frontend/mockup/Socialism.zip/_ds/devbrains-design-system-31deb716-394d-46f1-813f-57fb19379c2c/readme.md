# Devbrains Design System

Devbrains is a Swedish IT consulting company (Norrköping, Stockholm, Göteborg) providing senior
consultants and project deliveries in systemutveckling (software development), UX design, product
leadership and agile leadership. Clients include Arbetsförmedlingen, Polisen, SEB, Sveriges Radio,
Polestar, Volvo and Svenska Kraftnät. The company positions itself as a "family" of senior,
sociable tech nerds who value kindness, curiosity, joy and belonging alongside a "rebellious"
willingness to challenge convention. This system was built for Devbrains' own use — the pasted
brief describes them as "solving AI problems for mid to large companies" as a broader consulting
positioning; the live marketing site (below) is the concrete source of copy, tone and visuals used
to derive these foundations.

## Sources

- Live site: https://www.devbrains.se (home), `/vilka-vi-är` (Familjen/team), `/vad-vi-gor`
  (Kundcase/case studies), `/kontakt`. Built on the Snowfire CMS platform.
- User-attached screenshot: `uploads/Skärmavbild 2026-07-15 kl. 13.54.26.png` — homepage hero,
  showing the dark nav, gold hero panel, pencil-sketch eye illustration and pill CTA button.
  **Note:** this file's name contains a non-standard Unicode normalization that this project's
  file tools could not resolve programmatically (view-only). It was inspected visually but could
  not be cropped/copied as a shipped asset — see Caveats.
- No codebase, Figma file, or slide deck was attached. All tokens/colors/type below are estimated
  from the screenshot and the live site's rendered pages, not extracted from source CSS or design
  files. Flagged throughout as estimates.

## Index

- `styles.css` — root stylesheet, imports all tokens/fonts.
- `tokens/colors.css`, `tokens/typography.css`, `tokens/spacing.css`, `tokens/fonts.css`
- `assets/` — real logo (`logo-white-full.png`, white-on-transparent, dark-surface only), team
  photos, no other brand illustrations were retrievable (see Caveats).
- `components/core/` — Button, Badge, Tag, Card, Input, NavBar, PillLink
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Brand) shown in the Design
  System tab.
- `ui_kits/marketing-site/` — click-through recreation of the Devbrains marketing site (home,
  Familjen/team, a case study, contact).
- `SKILL.md` — portable skill file for use in Claude Code.

## Content fundamentals

- **Language:** All real copy is Swedish. Keep Swedish as the default for anything representing
  the live brand; use English only for internal/system labels.
- **Voice:** First-person plural throughout — "Vi är...", "Vi strävar...", "Vi bygger..." ("We
  are...", "We strive...", "We build..."). The company always speaks as "vi" (we), never "jag" (I),
  reinforcing the "family" framing. The reader is addressed informally and rarely directly ("du"
  appears mainly in CTAs like "Kontakta oss").
- **Tone:** Warm, personal, slightly informal — "sociala nördar" (social nerds), "gedigen
  erfarenhet" (solid experience) paired with soft, human language: "Hos oss är värderingar lika viktiga som kod. Vi bygger på en kultur av snällhet, nyfikenhet, glädje och tillhörighet." The
  brand explicitly names this tension as a value: being kind while being a "rebel" — "Vi är stolta över vår rebelliska inställning – vi vågar utmana det invanda och leverera resultat som sticker ut."
- **Casing:** Sentence case for headings and buttons ("Vi är Devbrains", "Kontakta oss", "Möt
  familjen") — never all-caps, never title case.
- **Structure:** Short paragraphs (2–4 sentences), section headers as full clauses/mini-sentences
  rather than single nouns ("Det är viktigt att vara snäll när man är rebell", "Välkommen till Villa
  Devbrains – Där innovation möter gemenskap").
- **Proof points:** Case studies follow a fixed shape — a client challenge paragraph, then
  "Lösning" (solution) and "Värde" (value) subheads with bolded action phrases, named to the
  specific consultant who delivered it (individual credit is a recurring pattern — e.g. "Oscar
  Cosmo levererade en lösning som...").
- **Emoji:** Not used on the website itself; used occasionally and sparingly in social copy
  (LinkedIn) — 😀🍾 in event-announcement posts only. Do not use emoji in product/marketing surfaces;
  fine only in casual social captions.
- **Signature line quotes:** Pull-quotes lean aphoristic and a little poetic: "Resultat är bara en trygghet inte ett mål i sig" and press-mention framing ("Läs mer om oss i denna artikel i DI").

## Visual foundations

*(Estimated from one screenshot + live rendered pages — no source CSS/Figma; treat exact hex/px
values as best-guess starting points, not ground truth. Flagging for user confirmation.)*

- **Color:** A dark, near-black charcoal (nav bar, footer, body backgrounds — est. `#16181d`) paired
  with a single warm mustard/gold accent (hero panel background, est. `#F3CE73`) used boldly as a
  full block, not a tint. Text on gold is a very dark ink navy/near-black (est. `#1B1E2A`), not pure
  black. Primary CTA buttons are solid black pills with white text — a third neutral, not the gold.
  This is a high-contrast, restrained two-tone brand (dark + gold) rather than a multi-color palette.
- **Type:** The wordmark ("devbrains") uses a distinctive rounded geometric display face with a
  ball-terminal dot on the "i" — this is locked inside the logo artwork, not a usable text font.
  Body/heading text in the rendered pages reads as a humanist geometric sans (rounded, friendly,
  moderate x-height) — closest available Google Fonts match is **Poppins** (flagged substitution,
  see below). Headings are set large and light-to-regular weight, sentence case, no letter-spacing
  tricks.
- **Backgrounds:** The homepage hero is full-bleed photography — a high-contrast, grainy pencil/
  charcoal sketch (an eye, textured like scratchboard/woodgrain) with a dark gradient scrim over the
  top third for nav legibility. This suggests the brand is comfortable with moody, textured,
  black-and-white editorial photography as a hero treatment, not flat illustration. No repeating
  patterns, no gradients on UI chrome (the only gradient seen is the nav scrim over the photo).
- **Imagery color vibe:** Cool, high-contrast black & white / grayscale with visible grain and hand-
  drawn texture for hero/editorial imagery; team headshots (see `assets/`) are warm, naturalistic
  color photography — a deliberate contrast between "arty" hero imagery and "human" team photography.
- **Buttons:** Fully-rounded pill shape (not rounded-rect), solid fill, no border, no shadow. Primary
  = black fill / white text. No visible secondary/ghost variant on the live site; a secondary
  (outline) style is an intentional addition here for UI-kit completeness.
- **Shadows/borders:** No visible drop shadows, borders, or card chrome on the marketing site itself
  — content sits in flat color blocks (the gold panel) or directly on white/dark. Any card
  affordances in the component set below (subtle 1px hairline borders) are intentional additions for
  a component library that has to represent lists/case-study grids the flat marketing site doesn't
  need.
- **Corner radii:** Large/full radius on buttons (pill); square or only slightly rounded corners
  elsewhere (nav, panels) — the brand does not use a soft "everything-rounded" card style.
  **Do not** default to rounded-corner-with-colored-left-border cards; nothing in the source uses
  that pattern.
- **Layout:** Simple top nav (logo left, 4 links right, active link underlined in gold), full-width
  hero split roughly 45/55 (gold text panel / photo), generous vertical rhythm between sections,
  each with alternating full-bleed image or flat color band. No sticky/fixed chrome observed beyond
  the top nav.
- **Motion:** Not observable from a static screenshot/text fetch — no hover/press/transition
  evidence available. Treat as unknown; the component set below uses conservative, standard
  (150–200ms ease) hover/press states as a safe default, flagged as an intentional addition.
- **Transparency/blur:** The only translucency observed is the dark gradient scrim over the hero
  photo (for nav contrast) — no frosted-glass/blur UI chrome observed.

## Iconography

No icon font, SVG icon set, or icon usage was found anywhere in the retrievable pages beyond the
logo mark itself (a small node/network + face-profile glyph, permanently fused into the logo
artwork — not a standalone reusable icon). No emoji are used as icons on the site. Because no
icon system was defined by the source, this design system links **Lucide** icons from CDN
(https://unpkg.com/lucide-static) as a close, neutral, single-weight stroke set for any UI-kit
chrome that needs icons (e.g. nav, contact form) — flagged as a substitution, not a brand asset.

## Caveats — please help me iterate

- **Only one screenshot + the live public pages were available** — no codebase, Figma file, or
  brand guideline doc. Every color/spacing/font value above is a visual estimate. If you have the
  original Figma file, brand guidelines PDF, or site repo, attaching it would let me replace every
  estimate with exact values.
- **The hero photograph you attached could not be extracted as a file** — its filename uses a
  Unicode normalization my file tools couldn't resolve for programmatic copy, so it's referenced
  here only as visual guidance, not shipped in `assets/`. Please re-upload it (or the source
  images) with a plain-ASCII filename and I'll pull it in properly.
- **No real webfont files exist in this system** — I substituted **Poppins** (Google Fonts) as the
  nearest match to the site's rounded geometric sans. If Devbrains has real license/font files,
  please share them and I'll swap `tokens/fonts.css` to the real family.
- **The component library and UI kit are original constructions**, not sourced from a real
  component library or codebase (none was attached) — I built a standard consulting-site component
  set (buttons, cards, nav, case-study tiles, forms) styled to match the two colors/type observed. If
  Devbrains has actual product UI (not just the marketing site) I should recreate that instead.
- **Ask:** tell me which of these estimates are wrong, and send the real assets (Figma, font files,
  brand PDF, product UI) so I can tighten this from "close guess" to "ground truth."
