/* @ds-bundle: {"format":4,"namespace":"DevbrainsDesignSystem_31deb7","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Tag","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"CaseCard","sourcePath":"components/core/Card.jsx"},{"name":"Input","sourcePath":"components/core/Input.jsx"},{"name":"NavBar","sourcePath":"components/core/NavBar.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"1a9468e28ae3","components/core/Button.jsx":"2617b1981241","components/core/Card.jsx":"964a26d24d45","components/core/Input.jsx":"ef78b7cf6e58","components/core/NavBar.jsx":"731c34a64aa7","ui_kits/marketing-site/CaseStudyScreen.jsx":"5ebad8c0a231","ui_kits/marketing-site/FamiljenScreen.jsx":"45ee7d970466","ui_kits/marketing-site/HomeScreen.jsx":"3cfc79e305ce","ui_kits/marketing-site/KontaktScreen.jsx":"57c79edb13e5","ui_kits/marketing-site/SiteFooter.jsx":"b83a3cbed937"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.DevbrainsDesignSystem_31deb7 = window.DevbrainsDesignSystem_31deb7 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function Badge({
  children,
  tone = 'gold'
}) {
  const tones = {
    gold: {
      background: 'var(--db-gold-300)',
      color: 'var(--text-on-accent)'
    },
    dark: {
      background: 'var(--db-ink-950)',
      color: 'var(--db-ink-0)'
    },
    outline: {
      background: 'transparent',
      color: 'var(--text-body)',
      border: '1px solid var(--border-hairline)'
    }
  };
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      fontFamily: 'var(--font-body)',
      font: 'var(--text-label)',
      padding: '4px 12px',
      borderRadius: 'var(--radius-pill)',
      ...tones[tone]
    }
  }, children);
}
function Tag({
  children
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      fontFamily: 'var(--font-body)',
      fontSize: '0.8125rem',
      padding: '5px 10px',
      borderRadius: 'var(--radius-sm)',
      background: 'var(--db-ink-100)',
      color: 'var(--text-body)'
    }
  }, children);
}
Object.assign(__ds_scope, { Badge, Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
const base = {
  fontFamily: 'var(--font-body)',
  fontWeight: 500,
  fontSize: '0.9rem',
  letterSpacing: 'var(--tracking-wide)',
  border: 'none',
  borderRadius: 'var(--radius-pill)',
  padding: '14px 28px',
  cursor: 'pointer',
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: '8px',
  transition: 'background var(--duration-base) var(--ease-standard), transform var(--duration-fast) var(--ease-standard), color var(--duration-base) var(--ease-standard)'
};
const variants = {
  primary: {
    background: 'var(--button-primary-bg)',
    color: 'var(--button-primary-text)'
  },
  secondary: {
    background: 'var(--button-secondary-bg)',
    color: 'var(--button-secondary-text)',
    border: '1.5px solid var(--button-secondary-border)'
  },
  accent: {
    background: 'var(--db-gold-500)',
    color: 'var(--text-on-accent)'
  }
};
const sizes = {
  md: {
    padding: '14px 28px',
    fontSize: '0.9rem'
  },
  sm: {
    padding: '9px 18px',
    fontSize: '0.8125rem'
  }
};
function Button({
  children,
  variant = 'primary',
  size = 'md',
  disabled = false,
  onClick,
  style
}) {
  const [hover, setHover] = React.useState(false);
  const v = variants[variant] || variants.primary;
  const s = sizes[size] || sizes.md;
  const hoverStyle = !disabled && hover ? variant === 'primary' ? {
    background: 'var(--button-primary-bg-hover)'
  } : variant === 'secondary' ? {
    background: 'var(--db-ink-100)'
  } : {
    background: 'var(--db-gold-700)'
  } : {};
  return /*#__PURE__*/React.createElement("button", {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    onClick: onClick,
    disabled: disabled,
    style: {
      ...base,
      ...v,
      ...s,
      ...hoverStyle,
      opacity: disabled ? 0.45 : 1,
      cursor: disabled ? 'not-allowed' : 'pointer',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function Card({
  children,
  padded = true,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      border: '1px solid var(--surface-card-border)',
      borderRadius: 'var(--radius-md)',
      padding: padded ? 'var(--space-5)' : 0,
      boxShadow: 'var(--shadow-sm)',
      fontFamily: 'var(--font-body)',
      ...style
    }
  }, children);
}
function CaseCard({
  title,
  excerpt,
  href = '#'
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", {
    href: href,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'block',
      textDecoration: 'none',
      background: 'var(--surface-card)',
      border: '1px solid var(--surface-card-border)',
      borderRadius: 'var(--radius-md)',
      padding: 'var(--space-5)',
      color: 'var(--text-body)',
      boxShadow: hover ? 'var(--shadow-md)' : 'var(--shadow-sm)',
      transform: hover ? 'translateY(-2px)' : 'none',
      transition: 'box-shadow var(--duration-base) var(--ease-standard), transform var(--duration-base) var(--ease-standard)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-h3)',
      marginBottom: 'var(--space-2)'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--text-muted)'
    }
  }, excerpt), /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-label)',
      color: 'var(--db-gold-700)',
      marginTop: 'var(--space-4)'
    }
  }, "L\xE4s mer \u2192"));
}
Object.assign(__ds_scope, { Card, CaseCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Input.jsx
try { (() => {
function Input({
  label,
  placeholder,
  type = 'text',
  required = false,
  textarea = false,
  value,
  onChange
}) {
  const [focus, setFocus] = React.useState(false);
  const fieldStyle = {
    width: '100%',
    boxSizing: 'border-box',
    fontFamily: 'var(--font-body)',
    font: 'var(--text-body)',
    padding: '12px 14px',
    borderRadius: 'var(--radius-md)',
    border: `1.5px solid ${focus ? 'var(--focus-ring)' : 'var(--border-hairline)'}`,
    outline: 'none',
    transition: 'border-color var(--duration-base) var(--ease-standard)',
    background: 'var(--db-ink-0)',
    color: 'var(--text-body)'
  };
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'block',
      marginBottom: 'var(--space-4)'
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      font: 'var(--text-label)',
      color: 'var(--text-muted)',
      marginBottom: 'var(--space-2)'
    }
  }, label, required && ' *'), textarea ? /*#__PURE__*/React.createElement("textarea", {
    placeholder: placeholder,
    value: value,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    rows: 4,
    style: fieldStyle
  }) : /*#__PURE__*/React.createElement("input", {
    type: type,
    placeholder: placeholder,
    value: value,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: fieldStyle
  }));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Input.jsx", error: String((e && e.message) || e) }); }

// components/core/NavBar.jsx
try { (() => {
function NavBar({
  links = [],
  activeHref,
  logoSrc,
  dark = true
}) {
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '20px 40px',
      background: dark ? 'var(--surface-dark)' : 'transparent',
      fontFamily: 'var(--font-body)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: logoSrc,
    alt: "Devbrains",
    style: {
      height: 34
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-6)'
    }
  }, links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l.href,
    href: l.href,
    style: {
      color: 'var(--db-ink-0)',
      textDecoration: 'none',
      font: 'var(--text-body-sm)',
      paddingBottom: 6,
      borderBottom: l.href === activeHref ? '2px solid var(--nav-active)' : '2px solid transparent'
    }
  }, l.label))));
}
Object.assign(__ds_scope, { NavBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/NavBar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/marketing-site/CaseStudyScreen.jsx
try { (() => {
function CaseStudyScreen({
  onNavigate
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)'
    }
  }, /*#__PURE__*/React.createElement(window.DevbrainsDesignSystem_31deb7.NavBar, {
    logoSrc: "../../assets/logo-white-full.png",
    links: [{
      label: 'Hem',
      href: '#home'
    }, {
      label: 'Familjen',
      href: '#familjen'
    }, {
      label: 'Kundcase',
      href: '#case'
    }, {
      label: 'Kontakt',
      href: '#kontakt'
    }],
    activeHref: "#case"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '56px 56px 20px',
      maxWidth: 720,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement(window.DevbrainsDesignSystem_31deb7.Badge, {
    tone: "gold"
  }, "Kundcase"), /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--text-h1)',
      margin: '16px 0 24px'
    }
  }, "Anv\xE4ndarv\xE4nlig app f\xF6r ruttplanering inom sj\xF6fart"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-body-lg)',
      color: 'var(--text-muted)',
      marginBottom: 32
    }
  }, "SMHI beh\xF6vde en l\xF6sning f\xF6r att effektivisera planeringen av fartygsrutter och g\xF6ra v\xE4der- och havsdata mer tillg\xE4ngliga f\xF6r kommersiella fartyg och rederier globalt."), /*#__PURE__*/React.createElement("h3", {
    style: {
      font: 'var(--text-h3)',
      marginBottom: 10
    }
  }, "L\xF6sning"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-body)',
      color: 'var(--text-muted)',
      marginBottom: 28
    }
  }, /*#__PURE__*/React.createElement("strong", null, "Utveckling av anv\xE4ndargr\xE4nssnitt:"), " Med hj\xE4lp av Knockout.js och Node.js skapade Oscar Cosmo ett gr\xE4nssnitt som gjorde det enkelt f\xF6r anv\xE4ndare att navigera i applikationen och planera rutter. ", /*#__PURE__*/React.createElement("strong", null, "Grafiskt tung applikation:"), " en visuellt intuitiv l\xF6sning som integrerade MapBox f\xF6r detaljerade kartor och ruttvisualiseringar."), /*#__PURE__*/React.createElement("h3", {
    style: {
      font: 'var(--text-h3)',
      marginBottom: 10
    }
  }, "V\xE4rde"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-body)',
      color: 'var(--text-muted)',
      marginBottom: 32
    }
  }, /*#__PURE__*/React.createElement("strong", null, "Effektivare ruttplanering:"), " snabb och exakt planering av fartygsrutter, vilket sparade tid och minskade kostnader f\xF6r rederier. ", /*#__PURE__*/React.createElement("strong", null, "Framtidss\xE4ker l\xF6sning:"), "en modern arkitektur som g\xF6r det enkelt att integrera nya funktioner vid behov."), /*#__PURE__*/React.createElement(window.DevbrainsDesignSystem_31deb7.Button, {
    variant: "primary",
    onClick: () => onNavigate('kontakt')
  }, "Kontakta oss")));
}
window.CaseStudyScreen = CaseStudyScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing-site/CaseStudyScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/marketing-site/FamiljenScreen.jsx
try { (() => {
const team = [{
  name: 'Andreas Edfast',
  img: '../../assets/team-andreas-edfast.jpg'
}, {
  name: 'Oscar Cosmo',
  img: '../../assets/team-oscar-cosmo.jpg'
}, {
  name: 'Christian Faström',
  img: '../../assets/team-christian-fastrom.jpg'
}, {
  name: 'Johan Alviander',
  img: '../../assets/team-johan-alviander.jpg'
}, {
  name: 'Erik Fremred',
  img: '../../assets/team-erik-fremred.jpg'
}, {
  name: 'Jessica Stålnacke',
  img: '../../assets/team-jessica-stalnacke.jpg'
}];
function FamiljenScreen({
  onNavigate
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)'
    }
  }, /*#__PURE__*/React.createElement(window.DevbrainsDesignSystem_31deb7.NavBar, {
    logoSrc: "../../assets/logo-white-full.png",
    links: [{
      label: 'Hem',
      href: '#home'
    }, {
      label: 'Familjen',
      href: '#familjen'
    }, {
      label: 'Kundcase',
      href: '#case'
    }, {
      label: 'Kontakt',
      href: '#kontakt'
    }],
    activeHref: "#familjen"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '56px 56px 24px',
      maxWidth: 760
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--text-h1)',
      margin: '0 0 16px'
    }
  }, "Om oss"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-body-lg)',
      color: 'var(--text-muted)'
    }
  }, "Vi p\xE5 Devbrains \xE4r seniora konsulter inom systemutveckling, UX-design, produkt- och projektledning samt agilt ledarskap. Vi finns i Norrk\xF6ping, G\xF6teborg och Stockholm.")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '24px 56px 80px',
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
      gap: 24
    }
  }, team.map(p => /*#__PURE__*/React.createElement("div", {
    key: p.name
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      aspectRatio: '5 / 6',
      borderRadius: 'var(--radius-md)',
      overflow: 'hidden',
      background: 'var(--db-ink-100)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: p.img,
    alt: p.name,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-h3)',
      marginTop: 10
    }
  }, p.name)))));
}
window.FamiljenScreen = FamiljenScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing-site/FamiljenScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/marketing-site/HomeScreen.jsx
try { (() => {
function HomeScreen({
  onNavigate
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)'
    }
  }, /*#__PURE__*/React.createElement(window.DevbrainsDesignSystem_31deb7.NavBar, {
    logoSrc: "../../assets/logo-white-full.png",
    links: [{
      label: 'Hem',
      href: '#home'
    }, {
      label: 'Familjen',
      href: '#familjen'
    }, {
      label: 'Kundcase',
      href: '#case'
    }, {
      label: 'Kontakt',
      href: '#kontakt'
    }],
    activeHref: "#home"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      minHeight: 460,
      background: 'var(--db-ink-200)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '0 0 46%',
      background: 'var(--db-gold-500)',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      padding: '0 56px',
      boxSizing: 'border-box',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--text-display-2)',
      color: 'var(--text-on-accent)',
      margin: 0
    }
  }, "Vi \xE4r Devbrains"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-body-lg)',
      color: 'var(--text-on-accent)',
      margin: 0,
      maxWidth: 460
    }
  }, "Vi \xE4r ett team av passionerade tech-entusiaster som brinner f\xF6r att g\xF6ra skillnad. Med senior expertis inom systemutveckling, design och digitalisering levererar vi l\xF6sningar som b\xE5de imponerar och fungerar."), /*#__PURE__*/React.createElement(window.DevbrainsDesignSystem_31deb7.Button, {
    variant: "primary",
    onClick: () => onNavigate('kontakt'),
    style: {
      width: 'fit-content'
    }
  }, "Kontakta oss")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      background: 'repeating-linear-gradient(120deg, #cfcfcf 0 2px, #9a9a9a 2px 4px, #e5e5e5 4px 7px)',
      filter: 'grayscale(1) contrast(1.15)',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(180deg, rgba(20,20,20,.55), transparent 40%)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: 16,
      right: 20,
      font: 'var(--text-body-sm)',
      color: '#fff',
      opacity: 0.6
    }
  }, "[ textured editorial photo placeholder \u2014 see readme Caveats ]"))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '72px 56px',
      maxWidth: 760,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--text-h1)',
      marginBottom: 20
    }
  }, "Det \xE4r viktigt att vara sn\xE4ll n\xE4r man \xE4r rebell"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-body)',
      color: 'var(--text-muted)'
    }
  }, "Hos oss \xE4r v\xE4rderingar lika viktiga som kod. Vi bygger p\xE5 en kultur av sn\xE4llhet, nyfikenhet, gl\xE4dje och tillh\xF6righet. Vi \xE4r stolta \xF6ver v\xE5r rebelliska inst\xE4llning \u2013 vi v\xE5gar utmana det invanda och leverera resultat som sticker ut."), /*#__PURE__*/React.createElement(window.DevbrainsDesignSystem_31deb7.Button, {
    variant: "secondary",
    onClick: () => onNavigate('familjen'),
    style: {
      marginTop: 24
    }
  }, "M\xF6t familjen")), /*#__PURE__*/React.createElement("div", {
    id: "case",
    style: {
      padding: '0 56px 80px',
      maxWidth: 1080,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--text-h1)',
      marginBottom: 28
    }
  }, "Kundcase"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(window.DevbrainsDesignSystem_31deb7.CaseCard, {
    title: "Anv\xE4ndarv\xE4nlig app f\xF6r ruttplanering inom sj\xF6fart",
    excerpt: "SMHI beh\xF6vde en l\xF6sning f\xF6r att effektivisera planeringen av fartygsrutter och g\xF6ra v\xE4der- och havsdata mer tillg\xE4ngliga.",
    href: "#kundcase-smhi"
  }), /*#__PURE__*/React.createElement(window.DevbrainsDesignSystem_31deb7.CaseCard, {
    title: "Serviceapp f\xF6r effektivare arbetsfl\xF6den",
    excerpt: "Volvo Car Retail Solution stod inf\xF6r behovet av att modernisera och effektivisera arbetsfl\xF6den f\xF6r sina servicetekniker.",
    href: "#"
  }), /*#__PURE__*/React.createElement(window.DevbrainsDesignSystem_31deb7.CaseCard, {
    title: "\xD6kad effekt inom it-st\xF6det f\xF6r anl\xE4ggningsunderh\xE5ll",
    excerpt: "Svenska Kraftn\xE4t beh\xF6vde \xF6ka effektiviteten och anv\xE4ndarnyttan av sitt IT-st\xF6d efter en uppgradering.",
    href: "#"
  }))));
}
window.HomeScreen = HomeScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing-site/HomeScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/marketing-site/KontaktScreen.jsx
try { (() => {
function KontaktScreen({
  onNavigate
}) {
  const [sent, setSent] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)'
    }
  }, /*#__PURE__*/React.createElement(window.DevbrainsDesignSystem_31deb7.NavBar, {
    logoSrc: "../../assets/logo-white-full.png",
    links: [{
      label: 'Hem',
      href: '#home'
    }, {
      label: 'Familjen',
      href: '#familjen'
    }, {
      label: 'Kundcase',
      href: '#case'
    }, {
      label: 'Kontakt',
      href: '#kontakt'
    }],
    activeHref: "#kontakt"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '56px',
      maxWidth: 480,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--text-h1)',
      marginBottom: 24
    }
  }, "Kontakta oss"), sent ? /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-body-lg)'
    }
  }, "Tack! Vi h\xF6r av oss snart.") : /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      setSent(true);
    }
  }, /*#__PURE__*/React.createElement(window.DevbrainsDesignSystem_31deb7.Input, {
    label: "Namn",
    required: true
  }), /*#__PURE__*/React.createElement(window.DevbrainsDesignSystem_31deb7.Input, {
    label: "E-post/Telefon",
    required: true
  }), /*#__PURE__*/React.createElement(window.DevbrainsDesignSystem_31deb7.Input, {
    label: "Meddelande",
    textarea: true
  }), /*#__PURE__*/React.createElement(window.DevbrainsDesignSystem_31deb7.Button, {
    variant: "primary"
  }, "Skicka"))));
}
window.KontaktScreen = KontaktScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing-site/KontaktScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/marketing-site/SiteFooter.jsx
try { (() => {
function SiteFooter() {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: 'var(--surface-dark)',
      color: 'var(--db-ink-0)',
      padding: '56px 40px 32px',
      fontFamily: 'var(--font-body)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 64,
      flexWrap: 'wrap',
      marginBottom: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 320
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-h3)',
      marginBottom: 12
    }
  }, "Devbrains"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--db-ink-400)'
    }
  }, "Vi \xE4r sociala n\xF6rdar som levererar seniora konsulttj\xE4nster inom systemutveckling och digitalisering. Vi v\xE4rnar om en kultur av nyfikenhet, gl\xE4dje, tillh\xF6righet och sn\xE4llhet.")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-h3)',
      marginBottom: 12
    }
  }, "H\xE4r finns vi"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--db-ink-400)',
      lineHeight: 2
    }
  }, "Norrk\xF6ping", /*#__PURE__*/React.createElement("br", null), "Stockholm", /*#__PURE__*/React.createElement("br", null), "G\xF6teborg")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-h3)',
      marginBottom: 12
    }
  }, "Kontakta oss"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--db-ink-400)',
      lineHeight: 2
    }
  }, "Johan Alviander 0733-69 70 44", /*#__PURE__*/React.createElement("br", null), "Erik Fremred 0760-10 21 04"))), /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-white-full.png",
    alt: "Devbrains",
    style: {
      height: 26,
      opacity: 0.85
    }
  }));
}
window.SiteFooter = SiteFooter;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing-site/SiteFooter.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.CaseCard = __ds_scope.CaseCard;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.NavBar = __ds_scope.NavBar;

})();
