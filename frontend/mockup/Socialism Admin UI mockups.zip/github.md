repo: kajmund/socialism
branch: main

## Last sync
date: 2026-08-12T19:51:22Z

### Updated in this project
- Added "SSR-ankare från körningen" (RunAnchorPoolPanel.tsx) inside the run results variant view: taggable quotes with source-type badge, interview question, tone/style dropdowns with removable label chips, "lägg även till i kalibrering" checkbox, and add-anchor button. Shown on the Pensionsålder — pilot run's Huvudspår attempt (non-A/B example).
- Added a run results screen grounded in frontend/src/components/runs/OasisResultsPanel.tsx and knowledge/manual/lasa-simuleringsresultat.md: expandable "försök" (attempts) with variant tabs (Huvudspår/A/B), action-distribution bar, top phrases, ämnesglidning bars, flöde (feed) with likes/dislikes/shares/comments, kopiera + intervjua actions, compare-attempts checkboxes, and a delete-attempt confirm modal. Reachable via "Öppna resultat" on non-draft Körningar cards/rows.
- Added a "Körningar" (Runs) list screen grounded in frontend/src/pages/RunsPage.tsx and frontend/src/styles/admin-runs.css: run cards (name, status tag, population, tick-dagar, variant A/B badges, updated date), search/status-filter/sort controls, duplicate/delete actions. Reachable via the top nav "Körningar" link (now wired alongside "Verktyg").
- Added an "Ankarpool" tab to the anchor-set editor (Ankare / Kalibrering / Test / Ankarpool) grounded in backend/app/services/anchor_pool.py: shows tagged pool items (comments/interviews) per label with search + label filter + remove, since centroid_vectors_for_set embeds the seed statement plus every pool item per label. Each label/statement row in Ankare now shows its tagged-example count with a link into the filtered pool view.
- Ankarset list now has a grid/list view toggle, and "Redigera" opens a new anchor-set editor screen grounded in frontend/src/pages/AnchorSetEditorPage.tsx and frontend/src/api/anchorSets.ts (label/statement pairs, calibration items, test-texts flow, published read-only state).
- Känslighet & rapportgränser tab reworked into a master-detail layout (one settings group shown at a time via a left menu) covering the full ReportThresholdsEditor.tsx surface.
- "Innehåll & ton" prompt editor covers all 37 real fields from backend/app/services/prompt_catalog.py in a searchable master-detail view.

## Notes for backend devs
- Consider merging `SsrAnchorSet.statements` (the per-label seed) into `SsrAnchorPoolItem` as a `source_type: "manual"` entry instead of a separate required column. Today `texts_for_label` special-cases the seed as always-present and hard-required, while pool items are optional extras — same centroid math, two different mechanisms. Collapsing them to "a label needs ≥1 pool item" (validated, not column-required) would remove that asymmetry and give admins one place to manage/correct every anchor text.

## Screen map
| Project screen | Repo files |
| --- | --- |
| Top nav | frontend/src/components/layout/AdminShell.tsx, frontend/src/styles/admin-runs.css |
| Tools tab bar | frontend/src/components/layout/ToolsShell.tsx |
| Configurations list | frontend/src/pages/ConfigurationsPage.tsx |
| Configuration editor | frontend/src/pages/ConfigurationEditorPage.tsx |
| Konfigurationer settings tabs | frontend/src/components/config/ReportThresholdsEditor.tsx, backend/app/services/prompt_catalog.py |
| Ankarset list | frontend/src/pages/AnchorSetsPage.tsx, frontend/src/api/anchorSets.ts |
| Ankarset editor — Ankarpool tab | backend/app/services/anchor_pool.py, backend/app/api/anchor_sets.py, frontend/src/api/anchorSets.ts (listPoolItems/deleteAnchorPoolItem) |
| Körningar list | frontend/src/pages/RunsPage.tsx, frontend/src/data/runs.ts, frontend/src/data/runs-types.ts, frontend/src/api/runs.ts, frontend/src/styles/admin-runs.css |
| Run results screen | frontend/src/components/runs/OasisResultsPanel.tsx, backend/app/services/run_results.py, knowledge/manual/lasa-simuleringsresultat.md |
| SSR-ankare från körningen | frontend/src/components/runs/RunAnchorPoolPanel.tsx |
| Tokens/fonts | frontend/src/index.css, frontend/index.html |
